﻿namespace Kindred.Rewards.Plugin.MessageConsumers.Exceptions;

public class MissionsRewardException : Exception
{
    public MissionsRewardException(string message) : base(message)
    {
    }
}
