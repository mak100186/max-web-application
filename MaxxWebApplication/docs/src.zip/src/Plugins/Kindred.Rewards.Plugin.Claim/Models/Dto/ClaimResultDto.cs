﻿using Kindred.Rewards.Core.Models.RewardClaims;

namespace Kindred.Rewards.Plugin.Claim.Models.Dto;

public class ClaimResultDto
{
    public RewardClaimPayoffMetadataDomainModel PayoffMetadata { get; init; }
}
