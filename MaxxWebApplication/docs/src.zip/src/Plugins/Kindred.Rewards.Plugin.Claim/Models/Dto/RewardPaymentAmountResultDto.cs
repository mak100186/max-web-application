﻿namespace Kindred.Rewards.Plugin.Claim.Models.Dto;

public class RewardPaymentAmountResultDto
{
    public decimal Payoff { get; init; }
}
