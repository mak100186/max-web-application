﻿namespace Kindred.Rewards.Plugin.Claim.Models.Dto;

public class SettleClaimResultDto
{
    public decimal? Payoff { get; init; }
}
