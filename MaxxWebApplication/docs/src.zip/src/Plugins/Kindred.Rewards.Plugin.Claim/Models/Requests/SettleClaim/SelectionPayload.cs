namespace Kindred.Rewards.Plugin.Claim.Models.Requests.SettleClaim;

public class SelectionPayload
{
    public string Outcome { get; set; }
}
