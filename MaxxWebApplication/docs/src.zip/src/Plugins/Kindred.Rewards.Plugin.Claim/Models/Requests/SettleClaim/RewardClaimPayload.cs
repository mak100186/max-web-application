﻿namespace Kindred.Rewards.Plugin.Claim.Models.Requests.SettleClaim;

public class RewardClaimPayload
{
    public string RewardRn { get; set; }
    public string ClaimRn { get; set; }
}
