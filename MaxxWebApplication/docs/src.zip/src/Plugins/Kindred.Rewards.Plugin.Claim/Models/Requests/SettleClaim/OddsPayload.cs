namespace Kindred.Rewards.Plugin.Claim.Models.Requests.SettleClaim;

public class OddsPayload
{
    public decimal Price { get; set; }
}
