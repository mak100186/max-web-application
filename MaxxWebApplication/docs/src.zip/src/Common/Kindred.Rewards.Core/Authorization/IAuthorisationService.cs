﻿namespace Kindred.Rewards.Core.Authorization;

public interface IAuthorisationService
{
    public string? GetUsername();
}
