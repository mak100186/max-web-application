﻿namespace Kindred.Rewards.Core.Models.Rewards;

#nullable enable
public class RewardPatchDomainModel
{
    public string? Name { get; set; }
    public string? Comments { get; set; }
}
