﻿namespace Kindred.Rewards.Core.Models.Events;

public class Selection
{
    public string Outcome { get; set; }
}
