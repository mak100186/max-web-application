﻿namespace Kindred.Rewards.Core.Models.RewardClaims;

public class RewardClaimOddsMetadataDomainModel
{
    public string Outcome { get; set; }
    public decimal Boosted { get; set; }
    public decimal Original { get; set; }
}
