﻿namespace Kindred.Rewards.Core.Models.RewardClaims;

public class RewardClaimPayoffMetadataDomainModel
{
    public List<RewardClaimOddsMetadataDomainModel> Odds { get; set; }
}
