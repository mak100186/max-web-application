﻿//legacy namespace Kindred.Rewards.Rewards.Logic.Models;
namespace Kindred.Rewards.Core.Models;

public class Odds
{
    public decimal Key { get; set; }

    public Dictionary<string, string> Display { get; set; } = new();

}
