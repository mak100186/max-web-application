namespace Kindred.Rewards.Core.Models.Messages;

public class RewardSettlement
{
    public bool ReturnStake { get; set; }
}
