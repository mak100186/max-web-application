﻿namespace Kindred.Rewards.Core.Models.Messages;

public class RewardClaimSettled : RewardClaim
{

}
