﻿namespace Kindred.Rewards.Core.Models.Messages.RewardTemplate;

public class RewardTemplateUpdated : RewardTemplate
{
}
