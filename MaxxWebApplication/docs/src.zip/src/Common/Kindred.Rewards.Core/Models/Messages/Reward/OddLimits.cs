﻿namespace Kindred.Rewards.Core.Models.Messages.Reward;

public class OddLimits
{
    public decimal? MinimumStageOdds { get; set; }
    public decimal? MinimumCompoundOdds { get; set; }
}
