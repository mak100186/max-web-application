﻿namespace Kindred.Rewards.Core.Models.Messages.Reward.Parameters;

public class RewardParametersBase
{
    public decimal? MaxExtraWinnings { get; set; }
    public string Type { get; set; }
}
