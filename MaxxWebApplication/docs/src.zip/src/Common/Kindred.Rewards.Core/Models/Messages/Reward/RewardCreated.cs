﻿namespace Kindred.Rewards.Core.Models.Messages.Reward;

public class RewardCreated : Reward
{
}
