﻿namespace Kindred.Rewards.Core.Models.Messages.RewardTemplate;

public class RewardTemplateCreated : RewardTemplate
{
}
