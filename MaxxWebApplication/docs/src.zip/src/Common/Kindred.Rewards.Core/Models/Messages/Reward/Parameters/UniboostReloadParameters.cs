﻿namespace Kindred.Rewards.Core.Models.Messages.Reward.Parameters;

public class UniBoostReloadParameters : UniBoostParameters
{
    public RewardReload Reload { get; set; }
}
