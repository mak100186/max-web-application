﻿namespace Kindred.Rewards.Core.Models.Messages.Reward.Parameters;

public class RewardReload
{
    public int? MaxReload { get; set; }

    public int StopOnMinimumWinBets { get; set; }
}
