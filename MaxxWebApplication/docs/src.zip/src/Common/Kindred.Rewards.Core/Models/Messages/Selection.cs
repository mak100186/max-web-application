﻿namespace Kindred.Rewards.Core.Models.Messages;

public class Selection
{
    public string Outcome { get; set; }
}
