﻿namespace Kindred.Rewards.Core.Models.Messages.Reward.Parameters;

public class FreeBetParameters : RewardParametersBase
{
    public decimal Amount { get; set; }
}
