﻿namespace Kindred.Rewards.Core.Models.Messages;

public class RewardClaimUnsettled : RewardClaim
{

}
