﻿namespace Kindred.Rewards.Core.Models.RewardConfiguration;

public class OddLimitsConfig
{
    public decimal? MinimumStageOdds { get; set; }
    public decimal? MinimumCompoundOdds { get; set; }
}
