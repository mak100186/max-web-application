namespace Kindred.Rewards.Core.Models.RewardConfiguration;

public class RewardReloadConfig
{
    public int? MaxReload { get; set; }

    public int StopOnMinimumWinBets { get; set; }
}
