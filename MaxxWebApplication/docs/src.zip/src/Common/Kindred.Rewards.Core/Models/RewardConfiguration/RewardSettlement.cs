namespace Kindred.Rewards.Core.Models.RewardConfiguration;

public class RewardSettlement
{
    public bool ReturnStake { get; set; }
}
