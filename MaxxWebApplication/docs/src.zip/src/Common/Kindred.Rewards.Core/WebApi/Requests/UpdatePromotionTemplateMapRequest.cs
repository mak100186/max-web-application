namespace Kindred.Rewards.Core.WebApi.Requests;

public class UpdatePromotionTemplateMapRequest
{
    public List<string> RewardRns { get; set; } = new();
}
