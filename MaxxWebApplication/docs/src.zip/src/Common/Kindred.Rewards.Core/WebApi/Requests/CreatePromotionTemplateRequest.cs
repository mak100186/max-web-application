namespace Kindred.Rewards.Core.WebApi.Requests;

public class CreateRewardTemplateRequest
{
    public string TemplateKey { get; set; }
    public string Comments { get; set; }
    public string Title { get; set; }
}
