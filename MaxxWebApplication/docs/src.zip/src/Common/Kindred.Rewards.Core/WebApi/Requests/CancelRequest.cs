namespace Kindred.Rewards.Core.WebApi.Requests;

public class CancelRequest
{
    public string Reason { get; set; }
}
