﻿using Kindred.Infrastructure.Hosting.WebApi.Extensions;

namespace Kindred.Rewards.Core.WebApi.Responses;
public class GetRewardsResponse : PagedResponse<GetRewardResponse>
{
}
