﻿namespace Kindred.Rewards.Core.WebApi.Responses;

public class GetAllowedMarketTypesResponse
{
    public List<string> OptionalParameterKeys { get; set; }

    public List<string> RequiredParameterKeys { get; set; }
}
