namespace Kindred.Rewards.Core.WebApi.Payloads;

public class SettlementApiModel
{
    public bool ReturnStake { get; set; }
}
