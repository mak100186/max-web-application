﻿namespace Kindred.Rewards.Core.WebApi.Payloads.BetModel;

public class OddsResponseApiModel
{
    public decimal RequestedPrice { get; set; }
}
