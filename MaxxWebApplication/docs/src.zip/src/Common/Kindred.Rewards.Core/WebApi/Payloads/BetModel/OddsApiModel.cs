﻿namespace Kindred.Rewards.Core.WebApi.Payloads.BetModel;

public class OddsApiModel
{
    public decimal RequestedPrice { get; set; }
}
