﻿namespace Kindred.Rewards.Core.WebApi.Payloads.BetModel;

public class SelectionApiModel
{
    public string Outcome { get; set; }
}
