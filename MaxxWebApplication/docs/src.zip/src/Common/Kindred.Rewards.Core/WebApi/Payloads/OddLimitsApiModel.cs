﻿namespace Kindred.Rewards.Core.WebApi.Payloads;

public class OddLimitsApiModel
{
    public decimal? MinimumStageOdds { get; set; }
    public decimal? MinimumCompoundOdds { get; set; }
}
