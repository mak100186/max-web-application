﻿namespace Kindred.Rewards.Core.WebApi.Enums;
public enum RewardType
{
    Uniboost,
    Profitboost,
    UniboostReload,
    Freebet,
}
