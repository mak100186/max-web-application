﻿namespace Kindred.Rewards.Core.WebApi.Enums;

public enum ContestStatus
{
    PreGame,
    InPlay
}
