﻿namespace Kindred.Rewards.Core.WebApi.Enums;
public enum SortableRewardClaimFields
{
    UpdatedOn
}
