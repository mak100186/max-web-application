﻿namespace Kindred.Rewards.Core.Enums;
public enum SortableRewardTemplateFields
{
    Enabled
}
