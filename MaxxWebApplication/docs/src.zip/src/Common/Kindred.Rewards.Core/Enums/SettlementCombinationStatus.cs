﻿namespace Kindred.Rewards.Core.Enums;

public enum SettlementCombinationStatus
{
    Pending,
    Resolved,
    Unresolved
}
