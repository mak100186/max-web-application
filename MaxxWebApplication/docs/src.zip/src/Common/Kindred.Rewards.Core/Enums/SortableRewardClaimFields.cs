﻿namespace Kindred.Rewards.Core.Enums;
public enum SortableRewardClaimFields
{
    UpdatedOn
}
