﻿namespace Kindred.Rewards.Core.Enums;

public enum BetTypes
{
    SingleLeg,
    StandardMultiLeg,
    SystemMultiLeg
}
