﻿namespace Kindred.Rewards.Core.Enums;

public enum ContestStatus
{
    PreGame,
    InPlay
}
