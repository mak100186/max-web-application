namespace Kindred.Rewards.Core.Enums;

public enum FeatureType
{
    /// <summary>
    /// Enables reload feature
    /// </summary>
    Reload = 1
}
