﻿namespace Kindred.Rewards.Core.Infrastructure.Data.DataModels;

public class RewardClaimPayoffMetadata
{
    public List<RewardClaimOddsMetadata> Odds { get; set; }
}
