﻿namespace Kindred.Rewards.Core.Infrastructure.Data.DataModels;

public class RewardClaimOddsMetadata
{
    public string Outcome { get; set; }
    public decimal Boosted { get; set; }
    public decimal Original { get; set; }
}
